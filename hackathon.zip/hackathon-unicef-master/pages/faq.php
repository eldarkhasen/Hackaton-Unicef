<section class="main-section paddind" id="Portfolio">
    <div class="container">
        <div class="row">
            <h2>Frequently asked questions</h2>
            <br><br>
            <div>
                <p class="question">How can I contact with the universities, colleges or academies?</p>
                <p class="answer">-On the page of the univercity you can find the link to the contact email.</p>
                <hr>
            </div>
            <div>
                <p class="question">How to send information about univercity about grants?</p>
                <p class="answer">-The last button on the navigation will help you with it.</p>
                <hr>
            </div>
            <div>
                <p class="question">How can i get information about university?</p>
                <p class="answer">-Page about grants will show you this kind of information.</p>
                <hr>
            </div>
            <div>
                <p class="question">What about payments and etc?</p>
                <p class="answer">-The representatives of univercities will answer to this question.</p>
                <hr>
            </div>
            <div>
                <p class="question">How can I contact with the universities, colleges or academies?</p>
                <p class="answer">-On the page of the univercity you can find the link to the contact email.</p>
            </div>
        </div>
    </div>
</section>

<section class="business-talking"><!--business-talking-start-->
	<div class="container">
        <h2>Send question</h2>
    </div>
</section><!--business-talking-end-->

<div class="container">
<section class="main-section contact" id="contact">
	
        <div class="row">
        	<div class="col-lg-6 col-sm-7 wow fadeInLeft">
            	<div class="contact-info-box address clearfix">
                	<h3><i class=" icon-map-marker"></i>Address:</h3>
                	<span>308 Negra Arroyo Lane<br>Albuquerque, New Mexico, 87111.</span>
                </div>
                <div class="contact-info-box phone clearfix">
                	<h3><i class="fa-phone"></i>Phone:</h3>
                	<span>1-800-BOO-YAHH</span>
                </div>
                <div class="contact-info-box email clearfix">
                	<h3><i class="fa-pencil"></i>email:</h3>
                	<span>hello@knightstudios.com</span>
                </div>
            	<div class="contact-info-box hours clearfix">
                	<h3><i class="fa-clock-o"></i>Hours:</h3>
                	<span><strong>Monday - Thursday:</strong> 10am - 6pm<br><strong>Friday:</strong> People work on Fridays now?<br><strong>Saturday - Sunday:</strong> Best not to ask.</span>
                </div>
                <ul class="social-link">
                	<li class="twitter"><a href="#"><i class="fa-twitter"></i></a></li>
                    <li class="facebook"><a href="#"><i class="fa-facebook"></i></a></li>
                    <li class="pinterest"><a href="#"><i class="fa-pinterest"></i></a></li>
                    <li class="gplus"><a href="#"><i class="fa-google-plus"></i></a></li>
                    <li class="dribbble"><a href="#"><i class="fa-dribbble"></i></a></li>
                </ul>
            </div>
        	<div id="sendInfo" class="col-lg-6 col-sm-5 wow fadeInUp delay-05s">
            	<div class="form">
                	<input class="input-text" type="text" name="" value="Your E-mail *" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                	<input class="input-text" type="text" name="" value="Your Name *" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">
                	<select required class="form-control input-lg" style="width: 536px ;">
                <option>University of Lincoln</option>
                <option>National College of medicine</option>
                <option>Nebraska University</option>
                <option>Academy of Science</option>
            </select>
                    
                	<textarea style="margin-top:17px" class="input-text text-area" cols="0" rows="0" onfocus="if(this.value==this.defaultValue)this.value='';" onblur="if(this.value=='')this.value=this.defaultValue;">Your Message *</textarea>
                    <input class="input-btn" type="submit" value="send message">
                </div>	
            </div>
        </div>
</section>
</div>