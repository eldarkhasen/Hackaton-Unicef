<section class="business-talking"><!--business-talking-start-->
	<div class="container">
        <h2>Let’s Talk About Mobility.</h2>
    </div>
</section><!--business-talking-end-->
<section class="main-section paddind" id="Portfolio">
    <div class="container">
        <div class="row">
            <h2>Search by your current university</h2><br>
            <select required class="form-control input-lg" style="width: 850px">
                <option>University of Lincoln</option>
                <option>National College of medicine</option>
                <option>Nebraska University</option>
                <option>Academy of Science</option>
            </select>
            <button id="search" style="width:80px; height:45px; float: right; margin-top:-45px; margin-left:-170px" class="btn btn-primary">Search</button>
            <div id="result" style="display: none; margin-top:30px" class="container">
                <div class="row">
                    <div class="col-md-9">
                        <div class="portfolioContainer wow fadeInUp delay-04s">
                        	<div class=" Portfolio-box printdesign">
                            	<a href="#"><img src="img/111.jpg" alt=""></a>
                            </div>
                            <div class="Portfolio-box webdesign">
                            	<a href="#"><img src="img/222.jpg" alt=""></a>
                            </div>
                            <div class=" Portfolio-box branding">
                            	<a href="#"><img src="img/333.jpg" alt=""></a>
                            </div>
                            <div class=" Portfolio-box photography" >
                            	<a href="#"><img src="img/444.jpg" alt=""></a>
                            </div>
                            <div class=" Portfolio-box branding">
                            	<a href="#"><img src="img/555.jpg" alt=""></a>
                            </div>
                            <div class=" Portfolio-box photography">
                            	<a href="#"><img src="img/666.jpg" alt=""></a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>