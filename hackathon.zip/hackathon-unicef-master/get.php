<html>
    <?php include "templates/properties.php"?>
<div style="overflow:hidden; position:relative;">
    
<header  class="header"><!--header-start-->

	    
	    <video style="position:absolute; top:-130px; left:0; width:100%" autoplay="autoplay" loop id=bg-video class=fullscreen-video>
			<source src="../asd.mp4" type="video/webm">
			<source src="../asd.mp4" type="video/mp4">

		</video>

	    <!--<video style="position: absolute; top:0" src="asd.mp4" autoplay="autoplay"></video>-->
    	<figure class="logo animated fadeInDown delay-07s" >
        	<a href="#"><i style="color:white" class="fa fa-university fa-5x" aria-hidden="true"></i></a>	
        </figure>	
        <h1 class="animated fadeInDown delay-07s">Welcome to Educational Support System</h1>
        <ul class="we-create animated fadeInUp delay-1s">
        	<li>We are a digital agency that helps to find grants in the world.</li>
        </ul>
            <a class="link animated fadeInUp delay-1s" href="index.php">Get Started</a>
    

</header><!--header-end-->
</div>
</html>    
