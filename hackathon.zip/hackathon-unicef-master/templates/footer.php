
    <footer class="footer">
        <div class="container">
            <span class="copyright">Copyright (c) 2016 | <a href="http://www.bitlab.kz">BitTab Junior</a> by BitLab Team</span>
        </div>
        <!-- 
            All links in the footer should remain intact. 
            Licenseing information is available at: http://bootstraptaste.com/license/
            You can buy this theme without footer links online at: http://bootstraptaste.com/buy/?theme=Knight
        -->
    </footer>
