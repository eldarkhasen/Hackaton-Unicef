<nav class="main-nav-outer" id="test"><!--main-nav-start-->
	<div class="container">
        <ul class="main-nav">
        	<li><a href="?">Grants</a></li>
            <li><a href="?page=centers">Centers</a></li>
            <li><a href="?page=mobility">Mobility</a></li>
            <li class="small-logo"><a href="?page=old"><i class="fa fa-graduation-cap fa-3x" aria-hidden="true"></i></a></li>
            <li><a href="?page=faq">FAQ</a></li>
            <li><a href="?page=about">About</a></li>
            <li><a href="?page=contact">Contact</a></li>
        </ul>
        <a class="res-nav_click" href="#"><i class="fa-bars"></i></a>
    </div>
</nav><!--main-nav-end-->